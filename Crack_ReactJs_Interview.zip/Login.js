import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
export const Login = () => {
    const navigate = useNavigate();
    const [val, setVal] = useState({
        "email": "",
        "password": ""
    });
    const [arr, setArr] = useState(()=>{
        let data = localStorage.getItem("restologin");
        if(data != null) {
            return JSON.parse(data);
        }
        else {
            return [];
        }
    })
    
    const inputHandler= (event) => {
        setVal({...val, [event.target.name]: event.target.value});
    }
    const login = (event) => {
        event.preventDefault();
        let newArr = arr.filter((items, index)=>{
            return items.email == val.email && items.password == val.password;
        });
        //console.log(newArr);
        if(newArr.length > 0){
            localStorage.setItem("status", true);
            navigate("/");
        }else {
            navigate("/login");
        }
        setVal({
            "email": "",
            "password": ""
        })
    }
  return (
    <div className='container'>
        <div className='title_heading'>
            <h1>Login</h1>
        </div>
        <div className='row'>
            <div className="col-sm-4 myform text-center mx-auto bg-dark mt-4" >
                <form action="" onSubmit={login}>
                    <div className='mt-3'>
                        <input type="email" name='email' onChange={inputHandler} className='form-control' placeholder='Email' value={val.email} />
                    </div>
                    <div className='mt-3'>
                        <input type="password" name='password' onChange={inputHandler} className='form-control' placeholder='Password' value={val.password} />
                    </div>
                    <div className='mt-3'>
                        <button type='submit'  className='btn btn-light loginBtn'>Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
  )
}
